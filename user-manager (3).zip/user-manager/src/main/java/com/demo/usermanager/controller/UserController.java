package com.demo.usermanager.controller;

import com.demo.usermanager.repository.UserRepository;
import com.demo.usermanager.repository.entity.User;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/users")
@AllArgsConstructor
public class UserController {

    private final UserRepository userRepository;

    @GetMapping("/welcome-user")
    public String welcomeUser(Model model) {
        List<User> users = userRepository.findAll();
        model.addAttribute("users", users);
        return "welcome-user";
    }
}
